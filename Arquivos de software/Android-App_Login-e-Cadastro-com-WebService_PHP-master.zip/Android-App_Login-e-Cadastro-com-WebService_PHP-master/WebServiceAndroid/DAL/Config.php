<?php

define('HOST', 'localhost:3306');
define('DBNAME', 'webservice');
define('USER', 'root');
define('PASSWORD', 'root');

define('SUCESSO', 1);
define('SEM_REGISTROS', 2);
define('ERRO_INSTRUCAO', 3);
define('ERRO_DB', 4);
define('PARAMETROS_INVALIDOS', 5);


