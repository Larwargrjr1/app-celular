package com.example.marcelo.consumindowebservice;

/**
 * Created by MARCELO on 11/12/2017.
 */

public class Constantes {

    /* EndPoints */
    /* Altere aqui para o endereço do servidor onde esta publicado o webservice */
    public final static String urlLogin = "http://192.168.1.101:8090/WebServiceAndroid/login.php";
    public final static String urlRegistrar = "http://192.168.1.101:8090/WebServiceAndroid/registrar.php";
}
