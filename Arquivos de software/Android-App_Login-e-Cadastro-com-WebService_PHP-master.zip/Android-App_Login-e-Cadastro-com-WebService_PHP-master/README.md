# Android-App_Login-e-Cadastro-com-WebService_PHP
Um aplicativo simples em Android, que permite o cadastro e login do usuario. Utiliza webservice em php (incluso) com banco de dados em MySQL.

O webservice completo em php está na pasta "WebServiceAndroid" também disponivel aqui. Nele em /DAL contém o arquivo Config no qual deve ser alterado as constantes para seus dados de conexão com o banco de dados.
No que se refere a aplicação Android, na classe Constantes, deve ser alterado os EndPoints, no caso, as url de requisição ao webservice. Modifique-os alterando para o endereço de seu servidor.

